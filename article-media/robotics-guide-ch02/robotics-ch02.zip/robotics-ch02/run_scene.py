"""Run the chapter-two scenes; --headless never creates a graphics context."""

import argparse
import csv
import hashlib
import json
import math
import platform
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent


def reset_scene(
    model: mujoco.MjModel, data: mujoco.MjData, config: dict[str, Any]
) -> None:
    """Reset all runtime data, then apply this scene's seeded initial state."""
    mujoco.mj_resetData(model, data)
    rng = np.random.default_rng(config["seed"])
    cube_adr = model.joint("cube_free").qposadr[0]
    data.qpos[cube_adr : cube_adr + 2] += rng.uniform(
        -config["cube_xy_jitter_m"], config["cube_xy_jitter_m"], size=2
    )
    for name, angle in config["joint_positions_rad"].items():
        joint = model.joint(name)
        if joint.type[0] != mujoco.mjtJoint.mjJNT_HINGE:
            raise ValueError(f"Initial angle requires a hinge joint: {name}")
        if not math.isfinite(angle) or not joint.range[0] <= angle <= joint.range[1]:
            raise ValueError(f"Initial angle outside joint range: {name}={angle}")
        data.qpos[joint.qposadr[0]] = angle
    mujoco.mj_forward(model, data)


def read_config(path: Path) -> dict[str, Any]:
    """Read the small, explicit configuration used by the lesson."""
    config = json.loads(path.read_text(encoding="utf-8"))
    if not math.isfinite(config["seconds"]) or not 0 < config["seconds"] <= 60:
        raise ValueError("seconds must be finite and in (0, 60]")
    if type(config["seed"]) is not int or not 0 <= config["seed"] < 2**32:
        raise ValueError("seed must be an integer in [0, 2**32)")
    jitter = config["cube_xy_jitter_m"]
    if not math.isfinite(jitter) or not 0 <= jitter <= 0.05:
        raise ValueError("cube_xy_jitter_m must be finite and in [0, 0.05]")
    if not isinstance(config["joint_positions_rad"], dict):
        raise ValueError("joint_positions_rad must be an object")
    return config


def model_fingerprint(model_path: Path) -> dict[str, str]:
    """Fingerprint this lesson's model and its one optional include file."""
    paths = [model_path]
    if model_path.name == "tabletop.xml":
        paths.append(model_path.with_name("drop.xml"))
    return {
        str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
        for p in paths
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", type=Path, default=ROOT / "config/drop.json")
    parser.add_argument(
        "--headless", action="store_true", help="Physics only, no viewer"
    )
    parser.add_argument(
        "--render", action="store_true", help="Also save final-frame.png (needs OpenGL)"
    )
    args = parser.parse_args()
    config_path = args.config.resolve()
    config = read_config(config_path)
    model_path = (ROOT / config["model"]).resolve()
    model = mujoco.MjModel.from_xml_path(str(model_path))
    data = mujoco.MjData(model)
    reset_scene(model, data, config)
    steps = math.ceil(config["seconds"] / model.opt.timestep)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = ROOT / "runs" / f"{model_path.stem}-{stamp}"
    output.mkdir(parents=True, exist_ok=False)
    (output / "config.json").write_text(
        json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    completed = 0
    started = time.perf_counter()

    with (output / "trajectory.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        writer.writerow(["time_s", "cube_x_m", "cube_y_m", "cube_z_m"])

        def record() -> None:
            # mj_step integrates qpos; update derived positions before recording.
            mujoco.mj_forward(model, data)
            writer.writerow([float(data.time), *data.body("cube").xpos.copy().tolist()])

        record()
        if args.headless:
            for _ in range(steps):
                mujoco.mj_step(model, data)
                completed += 1
                record()
        else:
            import mujoco.viewer as viewer_module

            with viewer_module.launch_passive(model, data) as viewer:
                with viewer.lock():
                    viewer.cam.lookat[:] = [0, 0, 0.65]
                    viewer.cam.distance = 1.8
                    viewer.cam.azimuth = 135
                    viewer.cam.elevation = -25
                while viewer.is_running() and completed < steps:
                    tick = time.perf_counter()
                    with viewer.lock():
                        mujoco.mj_step(model, data)
                        completed += 1
                        record()
                    viewer.sync()
                    time.sleep(
                        max(0, model.opt.timestep - (time.perf_counter() - tick))
                    )
        elapsed = time.perf_counter() - started
    finite = bool(np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all())
    summary = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "mujoco": mujoco.__version__,
        "numpy": np.__version__,
        "executable": sys.executable,
        "config": config,
        "model_sha256": model_fingerprint(model_path),
        "nq": model.nq,
        "nv": model.nv,
        "nu": model.nu,
        "timestep_s": float(model.opt.timestep),
        "requested_steps": steps,
        "completed_steps": completed,
        "complete": completed == steps,
        "sim_time_s": float(data.time),
        "loop_wall_time_s": elapsed,
        "headless": args.headless,
        "state_finite": finite,
        "cube_position_m": data.body("cube").xpos.copy().tolist(),
    }
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    print(
        json.dumps(
            {
                k: summary[k]
                for k in (
                    "nq",
                    "nv",
                    "nu",
                    "completed_steps",
                    "complete",
                    "sim_time_s",
                    "state_finite",
                    "cube_position_m",
                )
            },
            indent=2,
        )
    )
    print("Output:", output)
    if not finite:
        raise RuntimeError(
            "Non-finite simulation state; inspect the saved configuration"
        )
    if args.render:
        from PIL import Image

        with mujoco.Renderer(model, height=640, width=960) as renderer:
            renderer.update_scene(data, camera="overview")
            Image.fromarray(renderer.render()).save(output / "final-frame.png")


if __name__ == "__main__":
    main()
