"""Check the interpreter, imports and physics without opening a window."""

import platform
import sys

import mujoco
import numpy as np


def main() -> None:
    print("Python:", platform.python_version())
    print("Executable:", sys.executable)
    print("Platform:", platform.platform())
    print("MuJoCo:", mujoco.__version__, "NumPy:", np.__version__)
    model = mujoco.MjModel.from_xml_string(
        '<mujoco><worldbody><geom type="plane" size="1 1 0.1"/>'
        '<body pos="0 0 1"><freejoint/><geom type="sphere" size="0.05"/>'
        "</body></worldbody></mujoco>"
    )
    data = mujoco.MjData(model)
    mujoco.mj_step(model, data, nstep=10)
    assert data.time > 0 and np.isfinite(data.qpos).all()
    print(f"Physics OK: time={data.time:.6f} s, nq={model.nq}, nv={model.nv}")


if __name__ == "__main__":
    main()
