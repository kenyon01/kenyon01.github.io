# 第二章：搭建开发环境与第一个仿真

原文：https://www.dage.life/blog/2026/10/30/robotics-guide-02-environment-and-first-simulation/

这是随文的完整小实验，不含外部网格、预训练模型或真实机器人驱动。
Python 源码和 XML 是本章编写的教学示例；模型不对应某台商业机械臂。

## Windows PowerShell

在解压后的 `robotics-ch02` 目录中执行：

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe check_install.py
.\.venv\Scripts\python.exe quick_drop.py
.\.venv\Scripts\python.exe run_scene.py --headless
.\.venv\Scripts\python.exe run_scene.py --config config/tabletop.json --headless
.\.venv\Scripts\python.exe verify_lab.py
```

使用图形查看器（需要可用的桌面和 OpenGL）：

```powershell
.\.venv\Scripts\python.exe -m mujoco.viewer --mjcf=models/tabletop.xml
```

由脚本推进物理并同步窗口（配置默认运行 2 秒后关闭）：

```powershell
.\.venv\Scripts\python.exe run_scene.py --config config/tabletop.json
```

## Linux

使用已安装的 Python 3.13 创建独立环境。以下是等价命令，不表示已在本次验收中执行 Linux 测试。

```bash
python3.13 -m venv .venv
./.venv/bin/python -m pip install -r requirements.txt
./.venv/bin/python check_install.py
./.venv/bin/python run_scene.py --config config/tabletop.json --headless
./.venv/bin/python verify_lab.py
```

`--headless` 本身只算物理，不创建查看器或渲染器。`--render` 额外输出 PNG，需要图形上下文，不能据此断定无显卡服务器也一定能渲染。

## 输出与限制

- 每次运行生成独立的 `runs/<场景>-<UTC时间>/`，含配置、CSV 轨迹和 JSON 摘要。
- CSV 记录初始样本和每个步后的样本；2 秒、2 ms 步长对应 1000 步、1001 行数据。
- `complete` 只表示所需物理步数已执行，与任务成功无关。提前关闭窗口会记录 `complete: false`。
- `loop_wall_time_s` 覆盖运行循环；图形模式还包含建窗、同步和节拍等待，不是纯物理性能基准。
- `summary.json` 含本地解释器路径。公开自己的运行结果前可删去该路径；随文压缩包不含本次机器的运行目录。
- 随机种子控制本例方块初始平面偏移。它不承诺跨系统、不同库版本的逐位一致。
- 三关节机械臂使用各运动连杆的 `gravcomp="1"` 平衡重力，没有执行器、夹爪和闭环控制。末端橙色球只是标记，不会抓取物体。
- 只为本章两个模型记录直接 XML 依赖哈希；添加网格、纹理或更多 include 后，需要扩充依赖清单。

## 恢复环境

`requirements.txt` 固定直接依赖；`requirements-lock-windows.txt` 是本次 Windows 安装的完整包版本快照，不是跨平台锁文件。换平台优先使用前者，并另存自己的 `pip freeze` 与平台信息。

不要把 `.venv` 复制到另一台机器继续使用；保留本目录的源码、配置和依赖文件，在目标机器重建环境。
