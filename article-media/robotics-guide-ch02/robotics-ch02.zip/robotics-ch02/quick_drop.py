"""The short physics example printed in section 2.3."""

from pathlib import Path

import mujoco

root = Path(__file__).resolve().parent
model = mujoco.MjModel.from_xml_path(str(root / "models" / "drop.xml"))
data = mujoco.MjData(model)
mujoco.mj_forward(model, data)

print("nq, nv, nu:", model.nq, model.nv, model.nu)
print("start:", data.time, data.body("cube").xpos.copy())

for _ in range(1000):
    mujoco.mj_step(model, data)

mujoco.mj_forward(model, data)
print("end:", data.time, data.body("cube").xpos.copy())
print("contacts:", data.ncon)
