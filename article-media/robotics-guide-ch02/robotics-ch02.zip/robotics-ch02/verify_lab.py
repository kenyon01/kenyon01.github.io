"""Exercise both model files, seeded reset and contact settling without graphics."""

import numpy as np
import mujoco

from run_scene import ROOT, read_config, reset_scene


def main() -> None:
    for filename, expected in (("drop.json", (7, 6, 0)), ("tabletop.json", (10, 9, 0))):
        config = read_config(ROOT / "config" / filename)
        model = mujoco.MjModel.from_xml_path(str(ROOT / config["model"]))
        data = mujoco.MjData(model)
        reset_scene(model, data, config)
        initial = data.qpos.copy()
        assert (model.nq, model.nv, model.nu) == expected
        mujoco.mj_step(model, data, nstep=1000)
        mujoco.mj_forward(model, data)
        assert abs(data.time - 2.0) < 1e-9
        assert np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
        assert 0.715 < data.body("cube").xpos[2] < 0.725
        assert data.ncon > 0
        reset_scene(model, data, config)
        assert data.time == 0 and np.allclose(data.qvel, 0)
        np.testing.assert_array_equal(data.qpos, initial)
        other = dict(config, seed=43)
        reset_scene(model, data, other)
        assert not np.array_equal(data.qpos, initial)
        print(filename, "OK: dimensions, 1000 steps, contact, reset, seed")


if __name__ == "__main__":
    main()
