"""Targeted checks for mappings, rejection, timing, return and action replay."""

import json

import numpy as np

from control_lab import TICKS, checked_target, load_scene, run
from replay import replay


def main() -> None:
    model, data, qa, va, aids = load_scene()
    assert (model.nq, model.nv, model.nu) == (10, 9, 3)
    np.testing.assert_array_equal(qa, [7, 8, 9])
    np.testing.assert_array_equal(va, [6, 7, 8])
    np.testing.assert_array_equal(aids, [2, 0, 1])
    assert np.max(model.body_gravcomp) == 0
    for bad in ([0, 0], [float("nan"), 0, 1], [2, -0.6, 1]):
        try:
            checked_target(model, aids, np.array(bad))
        except ValueError:
            pass
        else:
            raise AssertionError(f"Invalid command accepted: {bad}")
    for amplitude, single in ((0.25, True), (0.15, False), (0.35, False)):
        folder = run(amplitude, single, False)
        meta = json.loads((folder / "summary.json").read_text(encoding="utf-8"))
        assert meta["complete"] and meta["returned_and_settled"]
        with np.load(folder / "states.npz", allow_pickle=False) as saved:
            assert len(saved["time"]) == TICKS + 1
            np.testing.assert_allclose(np.diff(saved["time"]), 0.01, atol=1e-12)
        normal = replay(folder, "actions")
        assert (
            normal["all_frames_processed"]
            and normal["max_joint_difference_rad"] < 1e-10
        )
        changed = replay(folder, "actions", perturb_yaw=0.1)
        assert changed["max_joint_difference_rad"] >= 0.099
        assert changed["max_joint_difference_after_step_rad"] > 0.01
        assert replay(folder, "state")["all_frames_processed"]
    print(
        "PASS: mappings, invalid targets, three runs, timestamp alignment, return and two replay modes"
    )


if __name__ == "__main__":
    main()
