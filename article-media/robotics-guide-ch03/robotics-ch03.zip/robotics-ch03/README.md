# 第三章：用 Python 控制与记录机器人运动

原文：https://www.dage.life/blog/2026/10/31/robotics-guide-03-python-control-and-motion-recording/

本包在第二章几何模型上加入位置伺服；各运动连杆的gravcomp已删除，积分器选择implicitfast。没有真实设备接口。本章只是仿真关节运动，不执行抓取。

## Windows PowerShell

进入解压后的 `robotics-ch03` 文件夹，执行：

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
.\.venv\Scripts\python.exe inspect_state.py
.\.venv\Scripts\python.exe control_lab.py --single
.\.venv\Scripts\python.exe control_lab.py --amplitude 0.15
.\.venv\Scripts\python.exe control_lab.py --amplitude 0.35
```

每次输出独立的 `runs/<UTC时间>/`。从终端复制实际目录，赋给变量，例如：

```powershell
$runDir = 'runs/把这里换成刚才实际生成的目录名'
.\.venv\Scripts\python.exe plot_run.py --run $runDir
.\.venv\Scripts\python.exe replay.py --run $runDir --mode actions
.\.venv\Scripts\python.exe replay.py --run $runDir --mode actions --perturb-yaw 0.1
.\.venv\Scripts\python.exe replay.py --run $runDir --mode state
```

看图形窗口时可给控制和回放命令添加 `--view`；默认不创建窗口。运行时间5秒，窗口会自动关闭。Linux中使用Python3.13创建环境后，把解释器命令换成 `./.venv/bin/python`，目录变量语法按实际Shell改写。

## 模型、单位和结果

- 统一关节顺序：base_yaw, shoulder, elbow；单位rad。
- XML执行器顺序刻意不同：shoulder_servo, elbow_servo, yaw_servo。程序通过名称建立映射。
- 物理步长2ms，每5步更新一次目标，即控制周期10ms；总计500个控制区间。
- 控制目标为绝对位置；没有每步累计增量。
- `complete` 表示500个控制区间完成；`returned_and_settled`另外检查最后50个采样点的位置误差与速度。
- 0.02rad、0.02rad/s、3rad/s和限位余量都是本场景教学设定，不是真机通用阈值。
- 状态保护在每个控制区间结束时检查，不保证捕获物理子步中的所有瞬态；不将其当成真实机器的安全控制器。
- CSV每一行绑定一个区间开始时的目标与区间结束时的测量；NPZ另有初始样本，长度多一行。
- NPZ不需要pickle；回放器以 `allow_pickle=False` 读取。只用自己产生或了解格式的运行记录。
- 动作回放恢复初始integration state，再重新执行保存的目标。模型和数值库版本须匹配。
- 状态重放直接写回qpos、qvel和time，不推进物理；它不还原全套接触力、传感器或控制器历史。
- 命令保护和状态保护在仿真中发现异常后停止迭代；进程停止不等于真实硬件制动。
- 正常结束、主动关窗、状态保护退出会保存结果；Ctrl+C、进程被终止或未预料的引擎/窗口异常不保证保存。记录暂存在内存中，本脚本不做实时崩溃恢复。

## 自检

```powershell
.\.venv\Scripts\python.exe verify_lab.py
```

检查名称映射、非法目标拒绝、单关节和两种多关节幅度、回到初始姿态、采样时间与动作回放。会生成三份小型运行结果。完整Windows包版本快照见requirements-lock-windows.txt；跨平台优先使用requirements.txt，在本机另存pip freeze。
