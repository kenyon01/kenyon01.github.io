"""Replay recorded commands through physics, or display recorded states."""

import argparse
from contextlib import nullcontext
import json
from pathlib import Path
import time

import mujoco
import numpy as np

from control_lab import SPEC, hashes, load_scene


def replay(
    folder: Path, mode: str, perturb_yaw: float = 0.0, view: bool = False
) -> dict:
    """Check model identity; compare action replay with the saved physical path."""
    meta = json.loads((folder / "summary.json").read_text(encoding="utf-8"))
    if (
        meta["model_sha256"] != hashes()
        or meta["mujoco"] != mujoco.__version__
        or meta["numpy"] != np.__version__
    ):
        raise ValueError(
            "Model or numerical library versions differ from the saved run"
        )
    if not np.isfinite(perturb_yaw) or abs(perturb_yaw) > 0.1:
        raise ValueError("perturb_yaw must be finite and within +/-0.1 rad")
    if mode == "state" and perturb_yaw != 0:
        raise ValueError("The state display does not accept an initial perturbation")
    with np.load(folder / "states.npz", allow_pickle=False) as saved:
        times, qpos, qvel = saved["time"], saved["qpos"], saved["qvel"]
        targets, initial = saved["targets"], saved["initial_integration_state"]
    model, data, qadr, vadr, aids = load_scene()
    mujoco.mj_setState(model, data, initial, SPEC)
    data.qpos[qadr[0]] += perturb_yaw
    mujoco.mj_forward(model, data)
    differences = [float(np.max(np.abs(data.qpos[qadr] - qpos[0, qadr])))]
    shown = 0
    if view:
        import mujoco.viewer as viewer_module

        context = viewer_module.launch_passive(model, data)
    else:
        context = nullcontext(None)
    with context as viewer:
        for i in range(len(targets)):
            if viewer is not None and not viewer.is_running():
                break
            with viewer.lock() if viewer is not None else nullcontext():
                if mode == "actions":
                    data.ctrl[aids] = targets[i]
                    for _ in range(meta["substeps"]):
                        mujoco.mj_step(model, data)
                    mujoco.mj_forward(model, data)
                    differences.append(
                        float(np.max(np.abs(data.qpos[qadr] - qpos[i + 1, qadr])))
                    )
                else:
                    # Display only: these writes replace the physical trajectory.
                    data.time = times[i + 1]
                    data.qpos[:] = qpos[i + 1]
                    data.qvel[:] = qvel[i + 1]
                    data.ctrl[aids] = targets[i]
                    mujoco.mj_forward(model, data)
                shown += 1
            if viewer is not None:
                viewer.sync()
                time.sleep(meta["control_dt_s"])
    result = {
        "mode": mode,
        "frames_processed": shown,
        "all_frames_processed": shown == len(targets),
    }
    if mode == "actions":
        result["max_joint_difference_rad"] = max(differences)
        result["initial_joint_difference_rad"] = differences[0]
        result["max_joint_difference_after_step_rad"] = max(
            differences[1:], default=0.0
        )
    print(json.dumps(result, indent=2))
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    parser.add_argument("--mode", choices=("actions", "state"), default="actions")
    parser.add_argument("--perturb-yaw", type=float, default=0.0)
    parser.add_argument("--view", action="store_true")
    args = parser.parse_args()
    replay(args.run, args.mode, args.perturb_yaw, args.view)
