"""Plot the saved commands and the subsequent observations; no simulator needed."""

import argparse
import json
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

plt.rcParams.update({"font.size": 13, "legend.fontsize": 12})


def plot(folder: Path) -> None:
    """Plot interval-held targets and post-step observations with their timestamps."""
    with np.load(folder / "states.npz", allow_pickle=False) as saved:
        times, qpos, targets = saved["time"], saved["qpos"], saved["targets"]
    if len(targets) == 0:
        raise ValueError(
            "No control intervals were recorded; there is no trajectory to plot"
        )

    meta = json.loads((folder / "summary.json").read_text(encoding="utf-8"))
    fig, axes = plt.subplots(3, 2, figsize=(12, 8), sharex=True)
    for j, name in enumerate(meta["joint_order"]):
        measured = qpos[:, meta["qpos_addresses"][j]]
        axes[j, 0].step(
            times,
            np.r_[targets[:, j], targets[-1, j]],
            where="post",
            label="target",
            color="#d18b22",
        )
        axes[j, 0].plot(times, measured, label="measured", color="#216886")
        axes[j, 0].set_ylabel(f"{name} [rad]")
        axes[j, 1].plot(times[1:], targets[:, j] - measured[1:], color="#157f79")
        axes[j, 1].set_ylabel("error [rad]")
        for ax in axes[j]:
            ax.grid(alpha=0.25)
            if times[-1] > 3.5:
                ax.axvspan(3.5, times[-1], color="#dbece6", alpha=0.35)
    axes[0, 0].legend()
    axes[0, 0].set_title("Held target and actual joint position")
    axes[0, 1].set_title("Interval target minus end-of-interval position")
    axes[-1, 0].set_xlabel("simulation time [s]")
    axes[-1, 1].set_xlabel("simulation time [s]")
    fig.suptitle(
        f"Amplitude {meta['amplitude_rad']:.2f} rad; gravity compensation disabled"
    )
    fig.tight_layout()
    fig.savefig(folder / "tracking.svg")
    fig.savefig(folder / "tracking.png", dpi=150)
    plt.close(fig)
    print(folder / "tracking.svg")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", type=Path, required=True)
    plot(parser.parse_args().run)
