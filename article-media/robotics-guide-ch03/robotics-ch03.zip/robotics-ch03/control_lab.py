"""Chapter-three controller, explicit name mappings and time-aligned logs."""

import argparse
from contextlib import nullcontext
import csv
from datetime import datetime, timezone
import hashlib
import json
import math
from pathlib import Path
import platform
import time

import mujoco
import numpy as np

ROOT = Path(__file__).resolve().parent
JOINTS = ("base_yaw", "shoulder", "elbow")
ACTUATORS = ("yaw_servo", "shoulder_servo", "elbow_servo")
HOME = np.array([0.0, -0.6, 1.0])
SUBSTEPS = 5
TICKS = 500
SPEC = mujoco.mjtState.mjSTATE_INTEGRATION


def load_scene() -> (
    tuple[mujoco.MjModel, mujoco.MjData, np.ndarray, np.ndarray, np.ndarray]
):
    """Return the scene and three distinct index maps in our documented order."""
    model = mujoco.MjModel.from_xml_path(str(ROOT / "models/controlled.xml"))
    data = mujoco.MjData(model)
    qadr = np.array([model.joint(name).qposadr[0] for name in JOINTS])
    vadr = np.array([model.joint(name).dofadr[0] for name in JOINTS])
    aids = np.array([model.actuator(name).id for name in ACTUATORS])
    for joint_name, actuator_name in zip(JOINTS, ACTUATORS):
        joint = model.joint(joint_name)
        actuator = model.actuator(actuator_name)
        if (
            joint.type[0] != mujoco.mjtJoint.mjJNT_HINGE
            or actuator.trnid[0] != joint.id
        ):
            raise ValueError("This lesson requires one position servo per named hinge")
    mujoco.mj_resetData(model, data)
    data.qpos[qadr] = HOME
    data.ctrl[aids] = HOME
    mujoco.mj_forward(model, data)
    return model, data, qadr, vadr, aids


def hashes() -> dict[str, str]:
    """Record all three XML files used by this self-contained lesson."""
    return {
        p.name: hashlib.sha256(p.read_bytes()).hexdigest()
        for p in sorted((ROOT / "models").glob("*.xml"))
    }


def checked_target(
    model: mujoco.MjModel, aids: np.ndarray, target: np.ndarray
) -> np.ndarray:
    """Reject incorrect dimensions, non-finite values and out-of-range commands."""
    result = np.asarray(target, dtype=float)
    if result.shape != (3,) or not np.isfinite(result).all():
        raise ValueError(
            "Target must have exactly three finite numbers in JOINTS order"
        )
    for i, (name, aid) in enumerate(zip(JOINTS, aids)):
        low, high = model.joint(name).range
        control_low, control_high = model.actuator_ctrlrange[aid]
        if (
            not max(low + 0.1, control_low)
            <= result[i]
            <= min(high - 0.1, control_high)
        ):
            raise ValueError(f"Target rejected for {name}: {result[i]} rad")
    return result.copy()


def reference(t: float, amplitude: float, single: bool) -> tuple[np.ndarray, str]:
    """Hold, ramp outward, hold, ramp home, then settle for 1.5 seconds."""
    if t < 0.5:
        weight, phase = 0.0, "initial_hold"
    elif t < 1.5:
        weight, phase = t - 0.5, "outward"
    elif t < 2.5:
        weight, phase = 1.0, "hold"
    elif t < 3.5:
        weight, phase = 3.5 - t, "return"
    else:
        weight, phase = 0.0, "settle"
    direction = np.array([1.0, 0.0, 0.0] if single else [1.0, 0.4, -0.4])
    return HOME + amplitude * weight * direction, phase


def run(amplitude: float, single: bool, view: bool) -> Path:
    """Run and save one bounded experiment; completion is separate from settling."""
    if not math.isfinite(amplitude) or amplitude < 0:
        raise ValueError("amplitude must be finite and non-negative")
    model, data, qadr, vadr, aids = load_scene()
    dt = float(model.opt.timestep) * SUBSTEPS
    plan = [reference(i * dt, amplitude, single) for i in range(TICKS)]
    plan = [(checked_target(model, aids, target), phase) for target, phase in plan]
    initial = np.empty(mujoco.mj_stateSize(model, SPEC))
    mujoco.mj_getState(model, data, initial, SPEC)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
    output = ROOT / "runs" / stamp
    output.mkdir(parents=True, exist_ok=False)
    times, positions, velocities = (
        [float(data.time)],
        [data.qpos.copy()],
        [data.qvel.copy()],
    )
    targets, rows = [], []
    reason = "completed"
    if view:
        import mujoco.viewer as viewer_module

        context = viewer_module.launch_passive(model, data)
    else:
        context = nullcontext(None)
    with context as viewer:
        for index, (target, phase) in enumerate(plan):
            if viewer is not None and not viewer.is_running():
                reason = "window_closed"
                break
            started = time.perf_counter()
            with viewer.lock() if viewer is not None else nullcontext():
                before = float(data.time)
                data.ctrl[aids] = target
                for _ in range(SUBSTEPS):
                    mujoco.mj_step(model, data)
                mujoco.mj_forward(model, data)
                positions.append(data.qpos.copy())
                velocities.append(data.qvel.copy())
                times.append(float(data.time))
                targets.append(target.copy())
                q = data.qpos[qadr].copy()
                v = data.qvel[vadr].copy()
                tip = data.site("tip").xpos.copy()
                rows.append(
                    [
                        index,
                        before,
                        float(data.time),
                        phase,
                        *target,
                        *q,
                        *v,
                        *(target - q),
                        *tip,
                    ]
                )
                finite = bool(
                    np.isfinite(data.qpos).all() and np.isfinite(data.qvel).all()
                )
                joint_inside = all(
                    model.joint(name).range[0] - 0.01
                    <= angle
                    <= model.joint(name).range[1] + 0.01
                    for name, angle in zip(JOINTS, q)
                )
                if (
                    not finite
                    or not joint_inside
                    or np.max(np.abs(v)) > 3.0
                    or abs(float(data.time) - before - dt) > 1e-9
                ):
                    reason = "state_guard"
            if reason == "state_guard":
                break
            if viewer is not None:
                viewer.sync()
                time.sleep(max(0, dt - (time.perf_counter() - started)))
    commands = np.asarray(targets, dtype=float).reshape(-1, 3)
    qpos = np.asarray(positions)
    qvel = np.asarray(velocities)
    count = len(commands)
    complete = count == TICKS and reason == "completed"
    tail_q = qpos[-50:, qadr]
    tail_v = qvel[-50:, vadr]
    settled = bool(
        complete
        and np.max(np.abs(tail_q - HOME)) < 0.02
        and np.max(np.abs(tail_v)) < 0.02
    )
    summary = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "mujoco": mujoco.__version__,
        "numpy": np.__version__,
        "model_sha256": hashes(),
        "joint_order": JOINTS,
        "actuator_order": ACTUATORS,
        "qpos_addresses": qadr.tolist(),
        "qvel_addresses": vadr.tolist(),
        "actuator_ids": aids.tolist(),
        "amplitude_rad": amplitude,
        "single_joint": single,
        "home_rad": HOME.tolist(),
        "physics_dt_s": float(model.opt.timestep),
        "substeps": SUBSTEPS,
        "control_dt_s": dt,
        "requested_ticks": TICKS,
        "completed_ticks": count,
        "stop_reason": reason,
        "complete": complete,
        "returned_and_settled": settled,
        "position_tolerance_rad": 0.02,
        "velocity_tolerance_rad_s": 0.02,
        "final_joint_error_rad": (HOME - qpos[-1, qadr]).tolist(),
        "tracking_rmse_rad": (
            np.sqrt(np.mean((commands - qpos[1:, qadr]) ** 2, axis=0)).tolist()
            if count
            else None
        ),
    }
    with (output / "trajectory.csv").open("w", newline="", encoding="utf-8") as stream:
        writer = csv.writer(stream)
        columns = ["tick", "command_time_s", "observation_time_s", "phase"]
        columns += [
            f"{prefix}_{name}"
            for prefix in ("target_rad", "q_rad", "v_rad_s", "error_rad")
            for name in JOINTS
        ]
        writer.writerow(columns + ["tip_x_m", "tip_y_m", "tip_z_m"])
        writer.writerows(rows)
    np.savez_compressed(
        output / "states.npz",
        time=np.asarray(times),
        qpos=qpos,
        qvel=qvel,
        targets=commands,
        initial_integration_state=initial,
    )
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2), encoding="utf-8"
    )
    print(
        json.dumps(
            {
                k: summary[k]
                for k in (
                    "completed_ticks",
                    "complete",
                    "returned_and_settled",
                    "final_joint_error_rad",
                    "tracking_rmse_rad",
                )
            },
            indent=2,
        )
    )
    print("Output:", output)
    if reason == "state_guard":
        raise RuntimeError("State guard stopped this simulation; inspect saved output")
    return output


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--amplitude", type=float, default=0.25)
    parser.add_argument("--single", action="store_true")
    parser.add_argument("--view", action="store_true")
    args = parser.parse_args()
    run(args.amplitude, args.single, args.view)
