"""Read names, independent index maps and the initial measured state."""

from control_lab import ACTUATORS, JOINTS, load_scene


def main() -> None:
    model, data, qadr, vadr, aids = load_scene()
    print("nq nv nu:", model.nq, model.nv, model.nu)
    for name, actuator, qa, va, aid in zip(JOINTS, ACTUATORS, qadr, vadr, aids):
        print(
            name,
            "joint_id=",
            model.joint(name).id,
            "qpos_address=",
            qa,
            "qvel_address=",
            va,
            "actuator=",
            actuator,
            "actuator_id=",
            aid,
        )
    print("time [s]:", data.time)
    print("q [rad]:", data.qpos[qadr].copy())
    print("qvel [rad/s]:", data.qvel[vadr].copy())
    print("tip world position [m]:", data.site("tip").xpos.copy())


if __name__ == "__main__":
    main()
